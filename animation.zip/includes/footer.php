


         
   

    </div>
    </div>






    





<div class="floatbutton">
    <div class="btns_wrap">
            
            <a href="javascript:;" class="chat_wrap" onclick="setButtonURL();">
              <span class="icoo"><i class="fa fa-comment"></i></span>
              <span>Chat With Us</span>
            </a>
            <a href="tel:+442033181217" class="call_wrap">
             <span class="icoo"><i class="fa fa-phone"></i></span>
              <span> +44 203 3181 217 </span>
            </a>
          </div>


      <div class="clickbutton"><div class="crossplus"><i class="fa fa-send"></i></div></div>
      <div class="banner-form">
        <h3>Chat With Us to <br><Strong class="fBold">Avail 50% Discount</Strong></h3>
        <div class="banform">
          <div class="container">
            <div class="row">
                <div class="ban-form">
                  <form class="cmxform" id="bannerform"  method="POST" action="webpages/floatingFormController.php">
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="username" name="fName" minlength="2" type="text" placeholder="Enter your name" required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="cemail" type="email" name="fEmail" placeholder="Enter email here" required>
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="phone-coun" name="fNumber" type="number" placeholder="Phone Number" required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <textarea name="fMessage" id="" rows="7" placeholder="Talk About Your Project"></textarea>
                        </div>
                      </div>
                      
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input name="submit" type="submit" placeholder="Connect With Us" required />
        
                          <script type="text/javascript">
                        document.getElementById('flocation').value = window.location.href;
                      </script>
                      <input type="hidden" name="hiddencapcha" value="">
                      <input type="hidden" id="flocation" name="flocationURL" value="" />
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
            </div>
          </div>
        </div>  
    </div>
    </div>



<div class="ys-layer"></div>
<div class="ys-container" id="ys-container">
   <div class="ys-box">
       <a class="ys-popup-close ys-exit" href="#">x</a>
       <div class="ys-popup-content">
           <!-- <p>Are Your Sure?</p>
           <a href="#" class="ys-exit">Exit</a> -->

           <div class="popupform tabform clearfix  text-left">
           <figure style="background-image: url(assets/images/linda-dok.jpg);"> </figure>
           <span class="heading">Confused? </span>
             <h2 class="text-center">Our smart and friendly client support team is available to guide you through the creative process and answer all of your questions.</h2>
             <form id="popupfrm" class="cmxform"  method="POST" action="webpages/exitFormController.php">

               <div class="fldst btnattach">
                 <!-- <input class="submit" type="submit" value="" class="btnsb" /> -->
                 <a class="callus" href="tel:++442033181217"> Free design consultation <i class="fa fa-phone"></i> +44 203 3181 217</a>
               </div>

               <div class="fldst">
                <p>Send us your number to speak with an actual human.</p>
                 <input id="phone-coun" name="fNumber" required="" type="number" rangelength="[2,15]" placeholder="Enter phone here">
                 <button class="newbtn" type="submit">Submit</button>
                 <script type="text/javascript">
                document.getElementById('location').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
              
              <input type="hidden" id="location" name="flocationURL" value="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>" />
               </div>

               
              
               <p class="lst-p">Not ready for a call? <a href="javascript:;" class="chatbtn" onclick="setButtonURL();"> Discuss with our stratigist</a></span></p>

             </form>
           </div>
       </div>
   </div>
</div>

<div class="stiky_foter">
  <figure style="background-image: url(assets/images/linda-dok.jpg);"> </figure>
  <p>Let’s conceptualize and design your idea 
with a creative professionals. </p>
  <a href="javascript:;" class="chatbtn linddbtn">Chat to get 50% Discount</a>
</div>




<script type='text/javascript' src='assets/js/mlib.js'></script>
<script type='text/javascript' src='assets/js/functions.js'></script>
<script type='text/javascript' src='assets/js/gsapAnimation.js'></script>


 
 
 <!-- Start of  Zendesk Widget script -->
<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=e14c5ecf-51eb-4644-8391-224bf793179d"> </script>
<!-- End of  Zendesk Widget script -->

 
 
<!--<script type="text/javascript">-->
<!--var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();-->
<!--(function(){-->
<!--var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];-->
<!--s1.async=true;-->
<!--s1.src='https://embed.tawk.to/5cec33b5a667a0210d59b031/1ddllnm92';-->
<!--s1.charset='UTF-8';-->
<!--s1.setAttribute('crossorigin','*');-->
<!--s0.parentNode.insertBefore(s1,s0);-->
<!--})();-->
<!--</script>-->




<script type="text/javascript">
function setButtonURL(){
 javascript:$zopim.livechat.window.show();
//Tawk_API.toggle();
}

$(document).on("click",".chatbtn",function(){
       javascript:$zopim.livechat.window.show();
    //Tawk_API.toggle();
});

$(document).on("click",".chat_tigger",function(){
  $zopim.livechat.window.toggle(); 
//Tawk_API.toggle();
   
   
});

</script>

<!--End of Tawk.to Script-->

 
 
 <script type="text/javascript">
    window._mfq = window._mfq || [];
    (function() {
        var mf = document.createElement("script");
        mf.type = "text/javascript"; mf.async = true;
        mf.src = "//cdn.mouseflow.com/projects/8f5af4e5-f50b-45e5-a6b0-559a17ba6c9f.js";
        document.getElementsByTagName("head")[0].appendChild(mf);
    })();
</script>
 


 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>

<script>
var options = {
debug: false,
}







 <!-- if ($.cookie('ysExit') == 1)
     {

     }
else{
 ysExit(options);
} -->

</script>



<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139554973-1"></script>
<script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-139554973-1');





</script>


<script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@12.0.0/dist/lazyload.min.js"></script>

<script>
  
  var myLazyLoad = new LazyLoad({
    elements_selector: ".lazy"
    // load_delay: 300 //adjust according to use case
});


</script>