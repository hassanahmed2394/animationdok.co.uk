<div class="container">
  <div class=" col-lg-12 col-xl-12 text-center">
    <div class="home-banner-content"  >
      <div class="analyzeform col-lg-10 offset-lg-1">
        <form class="" id="banform" method="POST" action="webpages/bannerFormController.php">
        <ul class="tags">
            <li class="item">
                <span class="wpcf7-form-control-wrap appdesign"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="2D Animation" /><span class="wpcf7-list-item-label">Explainer Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap webdesign"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="3D Animation" /><span class="wpcf7-list-item-label">2D Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap copywriting"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Character Animation" /><span class="wpcf7-list-item-label">3D Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap webdev"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Explainer Video Animation" /><span class="wpcf7-list-item-label">Product Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap motion"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Whiteboard Animation" /><span class="wpcf7-list-item-label">Corporate Video Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap branding"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Video Marketing" /><span class="wpcf7-list-item-label">Promotion Video</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap ios"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Design Illustration" /><span class="wpcf7-list-item-label">Whiteboard Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap ios"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Design Illustration" /><span class="wpcf7-list-item-label">Video Marketing</span></label></span></span></span>
            </li>
            
        </ul>
          <div class="row">
            <div class="wrap">
              <div class="dtf">
                <input id="fname" name="bName" autocomplete="off" minlength="5" class="round" type="text" placeholder="Enter Name" required="">
              </div>
              <div class="dtf">
                <input id="cemail" type="email" autocomplete="off" name="bEmail" placeholder="Enter email here" required="">
              </div>
              <div class="dtf">
                <input id="phone" name="bNumber" autocomplete="off" required="" type="number" rangelength="[2,15]" placeholder="Enter phone here">
              </div>
              <div class="dtf">
                <textarea name="bMessage" id="" rows="7" placeholder="Talk About Your Project"></textarea>
              </div>
              <div class="dtf text-left">
                <input class="submit" type="submit" value="Contact Team">
                <script type="text/javascript">
                document.getElementById('location').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
              <input type="hidden" id="location" name="blocationURL" value="" />
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>